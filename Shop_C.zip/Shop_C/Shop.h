#ifndef SHOP_H
#define SHOP_H

#include <stdbool.h>

// Оголошення структури для Товару (Product)
typedef struct {
    char name[100];
    double price;
    int stock_quantity;
} Product;

// Оголошення структури для Покупця (Customer)
typedef struct {
    char name[100];
    int age;
    double balance;
    bool is_regular; // Показує, чи є покупець постійним
    int bonus_points; // Бонусні бали
} Customer;

// Оголошення структури для Продавця (Seller)
typedef struct {
    char name[100];
    double salary;
    int sold_quantity; // Кількість проданих товарів
} Seller;

// Оголошення структури для Керівника Магазину (Manager)
typedef struct {
    char name[100];
    double salary;
} Manager;

// Оголошення структури для Магазину (Shop)
typedef struct {
    char name[100];
    Product products[100]; 
    Seller sellers[10]; 
    Manager manager; 
    int num_products; 
    int num_sellers; 
} Shop;

// Функції для роботи з магазином
void add_product(Shop* shop, Product product);
void remove_product(Shop* shop, char* product_name);
void display_shop_info(Shop* shop);
void make_purchase(Shop* shop, Customer* customer, char* product_name, int quantity);
void apply_discount(Shop* shop, const char* product_name, double discount_percentage);
void apply_devaluation(Shop* shop);

// Функції для роботи з файлами
void save_shop_to_file(Shop* shop, const char* filename);
void load_shop_from_file(Shop* shop, const char* filename);

#endif
