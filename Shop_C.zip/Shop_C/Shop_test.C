#include <stdio.h>
#include "Shop.h"

int main() {
    Shop shop = {"SuperShop", {}, {}, {"Manager", 5000.0}, 0, 1}; // Задаємо 1 продавця

    // Тест: додавання товару
    Product product1 = {"Кокос", 45.0, 10};
    Product product2 = {"Мандарини", 30.0, 20};
    add_product(&shop, product1);
    add_product(&shop, product2);

    // Виведення інформації про магазин
    display_shop_info(&shop);

    // Збереження магазину у файл
    save_shop_to_file(&shop, "shop_data.dat");

    // Завантаження магазину з файлу
    Shop loaded_shop;
    load_shop_from_file(&loaded_shop, "shop_data.dat");

    // Тест: покупка
    Customer customer = {"Анна", 35, 500.0, true, 0};
    printf("Покупець: %s\nБаланс: %.2f грн\nСтатус: %s\nБонусні бали: %d\n", 
        customer.name, customer.balance, customer.is_regular ? "Постійний клієнт" : "Новий клієнт", customer.bonus_points);
    make_purchase(&loaded_shop, &customer, "Кокос", 2);

    // Виведення оновленої інформації
    display_shop_info(&loaded_shop);
    printf("Покупець: %s\nБаланс: %.2f грн\nБонусні бали: %d\n", 
        customer.name, customer.balance, customer.bonus_points);

    return 0;
}
