#include <stdio.h>
#include <string.h>
#include "Shop.h"

// Додавання товару до магазину
void add_product(Shop* shop, Product product) {
    if (shop->num_products < 100) {
        shop->products[shop->num_products] = product;
        shop->num_products++;
    } else {
        printf("Магазин заповнений, не можна додати більше товарів.\n");
    }
}

// Видалення товару з магазину
void remove_product(Shop* shop, char* product_name) {
    for (int i = 0; i < shop->num_products; i++) {
        if (strcmp(shop->products[i].name, product_name) == 0) {
            for (int j = i; j < shop->num_products - 1; j++) {
                shop->products[j] = shop->products[j + 1];
            }
            shop->num_products--;
            printf("Товар '%s' видалено з магазину.\n", product_name);
            return;
        }
    }
    printf("Товар '%s' не знайдено в магазині.\n", product_name);
}

// Виведення інформації про магазин
void display_shop_info(Shop* shop) {
    printf("Магазин: %s\n", shop->name);
    printf("Список товарів:\n");
    for (int i = 0; i < shop->num_products; i++) {
        printf("- %s: %.2f грн, Кількість: %d\n", 
            shop->products[i].name, shop->products[i].price, shop->products[i].stock_quantity);
    }
    printf("Кількість продавців: %d\n", shop->num_sellers);
    printf("Керівник: %s\n", shop->manager.name);
}

// Покупка товару
void make_purchase(Shop* shop, Customer* customer, char* product_name, int quantity) {
    for (int i = 0; i < shop->num_products; i++) {
        if (strcmp(shop->products[i].name, product_name) == 0) {
            // Початкова ціна
            double initial_price = shop->products[i].price;
            printf("Початкова ціна на '%s': %.2f грн\n", product_name, initial_price);

            // Уцінка на товар
            apply_devaluation(shop);
            double price_after_devaluation = shop->products[i].price;
            printf("Ціна після уцінки: %.2f грн\n", price_after_devaluation);

            // Застосування знижки для постійного клієнта
            double total_cost = price_after_devaluation * quantity;

            if (customer->is_regular) {
                total_cost *= 0.9; // Знижка 10% для постійних клієнтів
            }

            if (customer->balance >= total_cost) {
                customer->balance -= total_cost;
                shop->products[i].stock_quantity -= quantity;
                printf("Покупка успішна! Ви придбали %d одиниць '%s' за %.2f грн.\n", 
                    quantity, product_name, total_cost);

                // Додавання бонусних балів
                int bonus_points = total_cost / 10; // 1 бал за кожні 10 грн
                customer->bonus_points += bonus_points;
                printf("Ви отримали %d бонусних балів! Загальна кількість: %d\n", bonus_points, customer->bonus_points);
                return;
            } else {
                printf("Недостатньо коштів для покупки.\n");
                return;
            }
        }
    }
    printf("Товар '%s' не знайдено в магазині.\n", product_name);
}

// Уцінка товарів
void apply_devaluation(Shop* shop) {
    for (int i = 0; i < shop->num_products; i++) {
        shop->products[i].price *= 0.95; // Зменшення ціни на 5%
    }
    printf("Ціни на товари уцінено на 5%%.\n");
}

// Запис магазину у файл
void save_shop_to_file(Shop* shop, const char* filename) {
    FILE* file = fopen(filename, "wb");
    if (file) {
        fwrite(shop, sizeof(Shop), 1, file);
        fclose(file);
        printf("Магазин успішно збережено до файлу '%s'.\n", filename);
    } else {
        printf("Не вдалося відкрити файл для запису.\n");
    }
}

// Завантаження магазину з файлу
void load_shop_from_file(Shop* shop, const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (file) {
        fread(shop, sizeof(Shop), 1, file);
        fclose(file);
        printf("Магазин успішно завантажено з файлу '%s'.\n", filename);
    } else {
        printf("Не вдалося відкрити файл для читання.\n");
    }
}
