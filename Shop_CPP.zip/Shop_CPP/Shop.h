#ifndef SHOP_H
#define SHOP_H

#include <string>
#include <vector>
#include <iostream>

// Клас для товару
class Product {
public:
    std::string name;
    double price;
    int stock_quantity;

    Product(const std::string& name, double price, int stock_quantity)
        : name(name), price(price), stock_quantity(stock_quantity) {}

    // Уцінка товару
    void apply_devaluation() {
        price *= 0.95; // Зниження ціни на 5%
    }

    // Виведення інформації про товар
    void print_product_info() const {
        std::cout << "- " << name << ": " << price << " грн, Кількість: " << stock_quantity << "\n";
    }
};

// Клас для покупця
class Customer {
public:
    std::string name;
    double balance;
    int bonus_points;
    bool is_regular; // true - постійний клієнт

    Customer(const std::string& name, double balance, bool is_regular)
        : name(name), balance(balance), bonus_points(0), is_regular(is_regular) {}

    // Функція для здійснення покупки
    void make_purchase(Product& product, int quantity) {
        double initial_price = product.price;
        std::cout << "Початкова ціна на '" << product.name << "': " << initial_price << " грн\n";

        product.apply_devaluation();
        double price_after_devaluation = product.price;
        std::cout << "Ціна після уцінки: " << price_after_devaluation << " грн\n";

        // Обчислення вартості покупки
        double total_cost = price_after_devaluation * quantity;

        // Знижка для постійних клієнтів
        if (is_regular) {
            total_cost *= 0.9; // Знижка 10% для постійних клієнтів
            std::cout << "Застосовано знижку для постійного клієнта 10%\n";
        }

        // Перевірка на достатність балансу
        if (balance >= total_cost) {
            balance -= total_cost;
            product.stock_quantity -= quantity;
            std::cout << "Покупка успішна! Ви придбали " << quantity << " одиниць '"
                      << product.name << "' за " << total_cost << " грн.\n";

            int earned_bonus_points = total_cost / 10; // 1 бал за кожні 10 грн
            bonus_points += earned_bonus_points;
            std::cout << "Ви отримали " << earned_bonus_points << " бонусних балів! Загальна кількість: " 
                      << bonus_points << "\n";
        } else {
            std::cout << "Недостатньо коштів для покупки.\n";
        }
    }
};

// Клас для магазину
class Shop {
public:
    std::string name;
    std::vector<Product> products;
    std::vector<Customer*> salespeople;

    Shop(const std::string& name) : name(name) {}

    // Виведення деталей магазину
    void print_details() {
        std::cout << "Магазин: " << name << "\n";
        std::cout << "Список товарів:\n";
        for (auto& product : products) {
            product.print_product_info();
        }
        std::cout << "Кількість продавців: " << salespeople.size() << "\n";
        std::cout << "Керівник: " << (salespeople.empty() ? "N/A" : salespeople[0]->name) << "\n";
    }
};

#endif // SHOP_H
