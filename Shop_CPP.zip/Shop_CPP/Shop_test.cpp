#include <iostream>
#include "shop.h"

int main() {
    // Створення магазину та товарів
    Shop shop("SuperShop");

    Product product1("Кокос", 45.00, 10);
    Product product2("Мандарини", 30.00, 20);

    shop.products.push_back(product1);
    shop.products.push_back(product2);

    // Створення покупця
    Customer customer("Анна", 500.00, true); // Анна - постійний клієнт
    shop.salespeople.push_back(&customer);

    // Виведення початкової інформації про магазин
    shop.print_details();

    // Виконання покупки
    customer.make_purchase(shop.products[0], 2); // Покупка 2 кокосів

    // Виведення змін після покупки
    shop.print_details();
    std::cout << "Покупець: " << customer.name << "\n";
    std::cout << "Баланс: " << customer.balance << " грн\n";
    std::cout << "Бонусні бали: " << customer.bonus_points << "\n";

    return 0;
}
